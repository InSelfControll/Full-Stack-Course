        function scrollToTop() {
            window.scrollTo(0, 0);
        }